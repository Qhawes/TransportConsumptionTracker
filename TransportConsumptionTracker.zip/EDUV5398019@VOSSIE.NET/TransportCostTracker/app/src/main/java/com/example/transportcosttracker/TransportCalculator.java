package com.example.transportcosttracker;

public class TransportCalculator {

    public double calculateDailyCost(double distancePerDay, double costPerKm) {
        double dailyCost = distancePerDay * costPerKm;
        return dailyCost;
    }

    public double calculateMonthlyCost(double dailyCost, int travelDays) {
        double monthlyCost = dailyCost * travelDays;
        return monthlyCost;
    }

    public double calculateMonthlyDistance(double distancePerDay, int travelDays) {
        double monthlyDistance = distancePerDay * travelDays;
        return monthlyDistance;
    }
}
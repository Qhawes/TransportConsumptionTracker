package com.example.transportcosttracker;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "TransportCostTracker.db";
    private static final int DATABASE_VERSION = 1;

    private static final String TABLE_NAME = "transport_records";
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_MODE = "mode_of_transport";
    private static final String COLUMN_TRANSPORT_TYPE = "transport_type";
    private static final String COLUMN_DAILY_COST = "daily_cost";
    private static final String COLUMN_MONTHLY_COST = "monthly_cost";
    private static final String COLUMN_MONTHLY_DISTANCE = "monthly_distance";
    private static final String COLUMN_COST_CATEGORY = "cost_category";
    private static final String COLUMN_RECOMMENDATION = "recommendation";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTableQuery = "CREATE TABLE " + TABLE_NAME + " (" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_MODE + " TEXT, " +
                COLUMN_TRANSPORT_TYPE + " TEXT, " +
                COLUMN_DAILY_COST + " REAL, " +
                COLUMN_MONTHLY_COST + " REAL, " +
                COLUMN_MONTHLY_DISTANCE + " REAL, " +
                COLUMN_COST_CATEGORY + " TEXT, " +
                COLUMN_RECOMMENDATION + " TEXT)";
        db.execSQL(createTableQuery);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    public long insertTransport(String mode, String transportType, double dailyCost, double monthlyCost, double monthlyDistance, String costCategory, String recommendation) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COLUMN_MODE, mode);
        values.put(COLUMN_TRANSPORT_TYPE, transportType);
        values.put(COLUMN_DAILY_COST, dailyCost);
        values.put(COLUMN_MONTHLY_COST, monthlyCost);
        values.put(COLUMN_MONTHLY_DISTANCE, monthlyDistance);
        values.put(COLUMN_COST_CATEGORY, costCategory);
        values.put(COLUMN_RECOMMENDATION, recommendation);

        long newRowId = db.insert(TABLE_NAME, null, values);
        db.close();
        return newRowId;
    }

    public Cursor getTransportById(long id) {
        SQLiteDatabase db = this.getReadableDatabase();
        String selection = COLUMN_ID + " = ?";
        String[] selectionArgs = { String.valueOf(id) };

        Cursor cursor = db.query(TABLE_NAME, null, selection, selectionArgs, null, null, null);

        if (cursor != null) {
            cursor.moveToFirst();
        }

        return cursor;
    }
}
package com.example.transportcosttracker;

public class Recommendation {

    public String getCostCategory(double monthlyCost) {
        String category;

        if (monthlyCost < 1000) {
            category = "Low Cost";
        } else if (monthlyCost < 2000) {
            category = "Moderate";
        } else if (monthlyCost < 3000) {
            category = "High";
        } else if (monthlyCost < 5000) {
            category = "Very High";
        } else {
            category = "Excessive";
        }

        return category;
    }

    public String getRecommendation(String costCategory) {
        String message;

        if (costCategory.equals("Low Cost")) {
            message = "Continue using your current transport method.";
        } else if (costCategory.equals("Moderate")) {
            message = "Consider carpooling where possible.";
        } else if (costCategory.equals("High")) {
            message = "Reduce unnecessary trips and combine errands.";
        } else if (costCategory.equals("Very High")) {
            message = "Consider public transport for regular commuting.";
        } else if (costCategory.equals("Excessive")) {
            message = "Immediate action is recommended to reduce transport costs.";
        } else {
            message = "Unable to determine a recommendation.";
        }

        return message;
    }
}
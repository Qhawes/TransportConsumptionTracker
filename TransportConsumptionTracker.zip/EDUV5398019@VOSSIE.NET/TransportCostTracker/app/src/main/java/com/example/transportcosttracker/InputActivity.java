package com.example.transportcosttracker;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class InputActivity extends AppCompatActivity {

    private EditText etModeOfTransport;
    private EditText etDistancePerDay;
    private EditText etCostPerKm;
    private DatePicker dpTravelDays;
    private Spinner spTransportType;

    private TransportCalculator transportCalculator;
    private Recommendation recommendation;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_input);

        transportCalculator = new TransportCalculator();
        recommendation = new Recommendation();
        databaseHelper = new DatabaseHelper(this);

        etModeOfTransport = findViewById(R.id.etModeOfTransport);
        etDistancePerDay = findViewById(R.id.etDistancePerDay);
        etCostPerKm = findViewById(R.id.etCostPerKm);
        dpTravelDays = findViewById(R.id.dpTravelDays);
        spTransportType = findViewById(R.id.spTransportType);

        Button btnCalculateSave = findViewById(R.id.btnCalculateSave);
        Button btnClear = findViewById(R.id.btnClear);

        btnCalculateSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calculateAndSave();
            }
        });

        btnClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clearFields();
            }
        });
    }

    private void calculateAndSave() {
        String mode = etModeOfTransport.getText().toString().trim();
        String distanceText = etDistancePerDay.getText().toString().trim();
        String costText = etCostPerKm.getText().toString().trim();
        String transportType = spTransportType.getSelectedItem().toString();
        int travelDays = dpTravelDays.getDayOfMonth();

        if (mode.isEmpty()) {
            Toast.makeText(this, "Please enter the Mode of Transport", Toast.LENGTH_SHORT).show();
            return;
        }

        if (distanceText.isEmpty()) {
            Toast.makeText(this, "Please enter the Distance Travelled per Day", Toast.LENGTH_SHORT).show();
            return;
        }

        if (costText.isEmpty()) {
            Toast.makeText(this, "Please enter the Cost per Kilometre", Toast.LENGTH_SHORT).show();
            return;
        }

        double distancePerDay;
        double costPerKm;

        try {
            distancePerDay = Double.parseDouble(distanceText);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Distance Travelled must be a number", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            costPerKm = Double.parseDouble(costText);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Cost per Kilometre must be a number", Toast.LENGTH_SHORT).show();
            return;
        }

        if (travelDays <= 0) {
            Toast.makeText(this, "Travel Days must be a valid number", Toast.LENGTH_SHORT).show();
            return;
        }

        Transport transport = new Transport(mode, transportType, distancePerDay, costPerKm, travelDays);

        double dailyCost = transportCalculator.calculateDailyCost(transport.getDistancePerDay(), transport.getCostPerKm());
        double monthlyCost = transportCalculator.calculateMonthlyCost(dailyCost, transport.getTravelDays());
        double monthlyDistance = transportCalculator.calculateMonthlyDistance(transport.getDistancePerDay(), transport.getTravelDays());

        String costCategory = recommendation.getCostCategory(monthlyCost);
        String recommendationText = recommendation.getRecommendation(costCategory);

        long insertedId = databaseHelper.insertTransport(
                transport.getModeOfTransport(),
                transport.getTransportType(),
                dailyCost,
                monthlyCost,
                monthlyDistance,
                costCategory,
                recommendationText
        );

        Intent intent = new Intent(InputActivity.this, ResultsActivity.class);
        intent.putExtra("recordId", insertedId);
        startActivity(intent);
    }

    private void clearFields() {
        etModeOfTransport.setText("");
        etDistancePerDay.setText("");
        etCostPerKm.setText("");
        spTransportType.setSelection(0);
    }
}
package com.example.transportcosttracker;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class ResultsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_results);

        TextView tvModeOfTransport = findViewById(R.id.tvModeOfTransport);
        TextView tvDailyCost = findViewById(R.id.tvDailyCost);
        TextView tvMonthlyCost = findViewById(R.id.tvMonthlyCost);
        TextView tvMonthlyDistance = findViewById(R.id.tvMonthlyDistance);
        TextView tvCostCategory = findViewById(R.id.tvCostCategory);
        TextView tvRecommendation = findViewById(R.id.tvRecommendation);

        Button btnCalculateAgain = findViewById(R.id.btnCalculateAgain);
        Button btnReturnHome = findViewById(R.id.btnReturnHome);
        Button btnExit = findViewById(R.id.btnExit);

        long recordId = getIntent().getLongExtra("recordId", -1);

        DatabaseHelper databaseHelper = new DatabaseHelper(this);
        Cursor cursor = databaseHelper.getTransportById(recordId);

        if (cursor != null && cursor.getCount() > 0) {
            String mode = cursor.getString(cursor.getColumnIndexOrThrow("mode_of_transport"));
            String transportType = cursor.getString(cursor.getColumnIndexOrThrow("transport_type"));
            double dailyCost = cursor.getDouble(cursor.getColumnIndexOrThrow("daily_cost"));
            double monthlyCost = cursor.getDouble(cursor.getColumnIndexOrThrow("monthly_cost"));
            double monthlyDistance = cursor.getDouble(cursor.getColumnIndexOrThrow("monthly_distance"));
            String costCategory = cursor.getString(cursor.getColumnIndexOrThrow("cost_category"));
            String recommendationText = cursor.getString(cursor.getColumnIndexOrThrow("recommendation"));

            tvModeOfTransport.setText("Mode of Transport: " + mode + " (" + transportType + ")");
            tvDailyCost.setText("Daily Transport Cost: R" + String.format("%.2f", dailyCost));
            tvMonthlyCost.setText("Monthly Transport Cost: R" + String.format("%.2f", monthlyCost));
            tvMonthlyDistance.setText("Monthly Distance Travelled: " + String.format("%.2f", monthlyDistance) + " km");
            tvCostCategory.setText("Transport Cost Category: " + costCategory);
            tvRecommendation.setText("Recommendation: " + recommendationText);

            cursor.close();
        }

        btnCalculateAgain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        btnReturnHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ResultsActivity.this, MainActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                finish();
            }
        });

        btnExit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finishAffinity();
            }
        });
    }
}
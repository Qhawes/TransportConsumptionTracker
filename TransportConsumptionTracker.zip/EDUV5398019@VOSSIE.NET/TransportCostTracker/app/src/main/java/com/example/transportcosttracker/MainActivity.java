package com.example.transportcosttracker;
import androidx.appcompat.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        Button btnStartCalculation = findViewById(R.id.btnStartCalculation);
        Button btnListenToMe = findViewById(R.id.btnListenToMe);
        Button btnExit = findViewById(R.id.btnExit);

        btnStartCalculation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, InputActivity.class);
                startActivity(intent);
            }
        });

        btnListenToMe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "Listening feature coming soon", Toast.LENGTH_SHORT).show();
            }
        });

        btnExit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.menuHome) {
            Toast.makeText(this, "You are on Home", Toast.LENGTH_SHORT).show();
            return true;
        } else if (id == R.id.menuDetails) {
            Toast.makeText(this, "Details selected", Toast.LENGTH_SHORT).show();
            return true;
        } else if (id == R.id.menuReports) {
            Toast.makeText(this, "Reports selected", Toast.LENGTH_SHORT).show();
            return true;
        } else if (id == R.id.menuHelp) {
            showHelpDialog();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
    private void showHelpDialog() {
        String helpMessage = "If calculations appear incorrect:\n\n" +
                "Verify all input values.\n\n" +
                "Ensure a travel date has been selected.\n\n" +
                "Confirm that distance and cost are numeric values.\n\n" +
                "Save the calculation before viewing reports.";

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Help");
        builder.setMessage(helpMessage);
        builder.setPositiveButton("OK", null);
        builder.show();
    }
}